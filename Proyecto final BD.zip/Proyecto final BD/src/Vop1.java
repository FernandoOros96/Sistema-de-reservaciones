import javax.swing.*;

public class Vop1 extends JDialog{
    public JTextField textFieldCurs;
    public JComboBox comboBoxSecc;
    public JComboBox comboBoxSem;
    public JTextField textFieldHor;
    public JTextField textFieldMin;
    public JTextField textFieldSem;
    public JComboBox comboBoxPe;
    private JPanel JPop1;
    public JButton AgregarBtn;

    public Vop1() {
        this.setContentPane(JPop1);
        this.pack();
        setLocationRelativeTo(null);
    }//end VconsH

    public static void main (String args[]){
        Vop1 w7= new Vop1();
        w7.setVisible(true);

    }//end main
}
