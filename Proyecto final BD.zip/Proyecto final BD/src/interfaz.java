
import javax.swing.*;
import javax.swing.plaf.nimbus.State;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
import java.util.ArrayList;

public class interfaz extends JFrame implements ActionListener  {

    int[] Hours=new int[]{1130, 1200, 1305, 1411, 1500, 1606, 1710, 1859, 1900};




    public static void main (String args[]) throws SQLException, Exception {
                    interfaz frame = new interfaz();
                    frame.setVisible(true);

    }//end main

    private static final int FRAME_WIDTH = 1000;

    private static final int FRAME_HEIGHT = 600;

    private static final int FRAME_X_ORIGIN = 150;

    private static final int FRAME_Y_ORIGIN = 50;

    private JButton consulta;
    private JButton reservacion;
    private JButton horario;
    private JButton salir;
    private JButton aceptar;

    private JLabel image;
    private JLabel etiqueta;
    public static JTextArea textArea;

    Connection conn = null;
    Statement stmt = null;
    BufferedReader in = null;

    static final String URL = "jdbc:mariadb://localhost:3306/";
    static final String BD = "test";		// especificar: el nombre de la BD,
    static final String USER = "root";		// el nombre de usuario
    static final String PASSWD = "Bangbang.25";// el password del usuario



    public interfaz() throws SQLException, Exception,IOException  {
//set the frame default properties


        setTitle("Administración de Horarios ");

        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setResizable(false);

        setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);


        changeBkColor( );
        Container contentPane= getContentPane();
        Color bg=new Color(245,245,220);
        contentPane.setBackground(bg);
        contentPane.setLayout(null);

        consulta = new JButton ("Consulta");
        consulta.setBounds(75,100,120,60);
        Color verd=new Color(189,236,18);
        consulta.setBackground(verd);
        contentPane.add(consulta);
        consulta.addActionListener(this);

        reservacion = new JButton ("Reservacion");
        reservacion.setBounds(75,200,120,60);
        Color nar= new Color(255,128,0);
        reservacion.setBackground(nar);
        contentPane.add(reservacion);
        reservacion.addActionListener(this);

        horario = new JButton ("Horario");
        horario.setBounds(75,300,120,60);
        Color azul=new Color(59,131,189);
        horario.setBackground(azul);
        contentPane.add(horario);
        horario.addActionListener(this);

        salir = new JButton ("Salir");
        salir.setBounds(820,470,120,60);
        Color red=new Color(255,0,0);
        salir.setBackground(red);
        contentPane.add(salir);
        salir.addActionListener(this);

        aceptar=new JButton("Aceptar");
        aceptar.setBounds(520,470,120,60);
        Color color= new Color(146,148,237);
        aceptar.setBackground(color);
        contentPane.add(aceptar);

        image= new JLabel(new ImageIcon("UDLAP_logo.png"));
        image.setBounds(1,1, 100,100);
        contentPane.add(image);

        etiqueta= new JLabel("Bienvenido a la base de datos");
        etiqueta.setBounds(300,20,650,50);
        etiqueta.setBackground(Color.blue);
        etiqueta.setForeground(Color.black);
        contentPane.add(etiqueta);

        textArea= new JTextArea("");
        textArea.setLineWrap(true);
        textArea.setBounds(300,75,650,350);
        textArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        textArea.setEditable(true);
        contentPane.add(textArea);

        JScrollPane scroll=new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBounds(300,75,650,350);
        contentPane.add(scroll);

        setDefaultCloseOperation( EXIT_ON_CLOSE );

// this will load the MySQL driver, each DB has its own driver
        Class.forName( "org.mariadb.jdbc.Driver" );
        textArea.setText( "Connecting to the database... " );

        // setup the connection with the DB
        conn = DriverManager.getConnection( URL+BD, USER, PASSWD );
        textArea.setText( "connected\n\n" );

        conn.setAutoCommit( false );         // inicio de la 1a transacción
        stmt = conn.createStatement();
        in = new BufferedReader( new InputStreamReader(System.in) );







    }//end interfaz

    // Métodos PRIVADOS

    private void changeBkColor()
    {
        Container contentPane = getContentPane();


    }//end changeBkColor

    private void dumpResultSet( ResultSet rset ) throws SQLException {

        textArea.setText("");
        ResultSetMetaData rsetmd = rset.getMetaData();
        int i = rsetmd.getColumnCount();
        String aux;


        while( rset.next() ) {

            for( int j = 1; j <= i; j++ ) {
                aux= rset.getString(j) + "\t" ;
                textArea.insert(aux ,0);
                System.out.print(aux);
            }
            System.out.println("");
        }

    }

    private void query( String statement ) throws SQLException {

        ResultSet rset = stmt.executeQuery( statement );
        etiqueta.setText( "Resultados:" );
        dumpResultSet( rset );

        System.out.println();
        rset.close();
    }

    public void mostrar(String tabla) throws  SQLException{
        String sql="select * from " + tabla;
        Tvisor wV= new Tvisor();
        wV.setVisible(true);
        DefaultTableModel model=new DefaultTableModel();
        model.addColumn("EMPNO");
        model.addColumn("ENAME");
        model.addColumn("JOB");
        model.addColumn("MGR");
        model.addColumn("HIREDATE");
        model.addColumn("SAL");
        model.addColumn("COMM");
        model.addColumn("DEPTNO");
        wV.visor.setModel(model);

        String [] datos=new String[8];
        try{
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                datos[7]=rs.getString(8);
                model.addRow(datos);
            }//end while
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Error" + e.toString());
        }//end catch
    }//end msotrar

    private void close() throws SQLException {

        stmt.close();
        conn.close();
    }

    private boolean revHora(int old,int dur,int ins ){
        boolean res=false;
        if(old<=ins && old + dur>=ins)
        {
         res=true;
        }else{
            res=false;
        }
        return res;

    }//end revisar coincidencia

        public void actionPerformed (ActionEvent event) {

            String menuName;
            menuName= event.getActionCommand();

            if(event.getSource() instanceof JButton)
            {

                JButton clickedButton= (JButton)event.getSource();
                String buttonText= clickedButton.getText();

                if(buttonText=="Consulta"){
                    Ventanasalon win= new Ventanasalon();
                    win.setVisible(true);
                    win.btnOK.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            String info =(String)win.XD.getSelectedItem();
                            try {
                                mostrar(info);
                                etiqueta.setText("");
                                //query( "select * from " + info );
                            } catch (SQLException throwables) {
                                throwables.printStackTrace();
                            }

                        }
                    });
                }//end if
                if(buttonText=="Reservacion")
                {
                   etiqueta.setText("Tecle 'C' para consultar un salón o Tecle 'R' para reservar un salón y presione aceptar");
                   textArea.setText("");
                   aceptar.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            String ans=textArea.getText();
                            textArea.setText(null);
                            if(ans.equals("C")){
                                VConsSal w2= new VConsSal();
                                w2.setVisible(true);
                                w2.OKButton.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        String info =w2.textField1.getText();
                                        String infoB=(String) w2.comboBox1.getSelectedItem();
                                        if(info.isEmpty())
                                        {
                                            textArea.setText(infoB);
                                        }
                                            if(infoB.equals("-seleccione-")){
                                                textArea.setText(info);
                                            }
                                            //textArea.setText(info+"-"+infoB);
                                        w2.dispose();
                                    }
                                });
                            }//end if
                            if(ans.equals("R")){
                                VResvSal w3= new VResvSal();
                                w3.setVisible(true);
                                w3.anularResBtn.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        VResvSal wA= new VResvSal();
                                        wA.setVisible(true);
                                        wA.anularResBtn.setVisible(false);
                                        wA.resvSB.setText("Anular Reservacion");
                                        wA.resvSB.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent e) {
                                                int x= JOptionPane.showConfirmDialog(null, "Está seguro de anular la reservación", "Anular reservación", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                                                if(x==0) {
                                                    String reserv= "delete from DEPT where deptno = "+ wA.textField1.getText() + " and dname = '" + wA.textField2.getText() + "'";
                                                    try {
                                                        stmt.executeUpdate(reserv);
                                                        conn.commit();
                                                        JOptionPane.showConfirmDialog(null,"Se ha anulado exitosamente","Registro",JOptionPane.OK_OPTION,JOptionPane.INFORMATION_MESSAGE);
                                                    } catch (SQLException throwables) {
                                                        JOptionPane.showMessageDialog(null,"Error: no se logró anular la reservación","Operación",JOptionPane.ERROR_MESSAGE);
                                                    }
                                                    textArea.setText(reserv);
                                                    wA.dispose();
                                                    w3.dispose();
                                                    //se anula la reservacion
                                                }
                                                if(x==1 || x==-1){
                                                    wA.textField1.setText(null);
                                                    wA.textField2.setText(null);
                                                    wA.dispose();
                                                    //No se anuló la reservación funcion
                                                }//end if
                                            }
                                        });
                                    }
                                });
                                w3.resvSB.setText("Realizar reservación");
                                w3.resvSB.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        int x= JOptionPane.showConfirmDialog(null, "Está seguro de reservar el salón", "Confirmar reservación", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                                        if(x==0) {
                                            String reserv= "insert into DEPT values ( "+ w3.textField1.getText() + ",'" + w3.textField2.getText() + "', 'MEX')";
                                            int h= Integer.parseInt(w3.textField1.getText());
                                            System.out.println(h);
                                            boolean ver;
                                            for(int i=0;i<Hours.length;i++){
                                                ver=revHora(Hours[i],45,h);
                                                if(ver){
                                                    System.out.println("Ya está reservado");
                                                }//end if
                                            }//end for

                                            /*
                                            try {
                                                stmt.executeUpdate(reserv);
                                                //conn.commit();
                                                JOptionPane.showConfirmDialog(null,"Se ha registrado exitosamente","Registro",JOptionPane.OK_OPTION,JOptionPane.INFORMATION_MESSAGE);
                                            } catch (SQLException throwables) {
                                                throwables.printStackTrace();
                                                System.out.println("ERROR XD");
                                            }

                                             */
                                            textArea.setText(reserv);
                                            w3.dispose();
                                        }
                                        if(x==1 || x==-1){
                                            w3.textField1.setText(null);
                                            w3.textField2.setText(null);
                                            //colocar que se abortó o no se realizó la transaccion
                                        }//end if
                                    }
                                });
                            }//end if
                        }
                    });
                }//end if
                if(buttonText=="Horario"){
                    etiqueta.setText("Tecle '1' para consultar el horario o Tecle '2' para modificarlo y presione aceptar");
                    textArea.setText("");
                    aceptar.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            String ans=textArea.getText();
                            textArea.setText(null);
                            if(ans.equals("1")){
                                VconsH w4= new VconsH();
                                w4.setVisible(true);
                                w4.Completobtn.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        textArea.setText("Completo");
                                        w4.dispose();
                                    }
                                });
                                w4.Consbtn.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        String infoA=(String) w4.comboBox1.getSelectedItem();
                                        String infoB=(String) w4.comboBox2.getSelectedItem();
                                        if(infoA.equals("-seleccione-"))
                                        {
                                            textArea.setText(infoB);
                                        }
                                        if(infoB.equals("-seleccione-")){
                                            textArea.setText(infoA);
                                        }
                                        //textArea.setText(info+"-"+infoB);
                                        w4.dispose();
                                    }
                                });
                            }//end if
                            if(ans.equals("2")){
                                Vpswrd w5= new Vpswrd();
                                w5.setVisible(true);
                                w5.ingbtn.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        String psw=w5.textField1.getText();
                                        if(psw.equals("1234"))
                                        {
                                            w5.dispose();
                                            VopHorario w6= new VopHorario();
                                            w6.setVisible(true);
                                            w6.aceptarBtn.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent e) {
                                                    String op=w6.group.getSelection().getActionCommand();
                                                    if(op.equals("1")){
                                                        Vop1 w7= new Vop1();
                                                        w7.setVisible(true);
                                                        w7.AgregarBtn.addActionListener(new ActionListener() {
                                                            public void actionPerformed(ActionEvent e) {
                                                                String curs=w7.textFieldCurs.getText();
                                                                String info1=(String) w7.comboBoxSecc.getSelectedItem();
                                                                String info2=(String) w7.comboBoxSem.getSelectedItem();
                                                                String info3=w7.textFieldHor.getText();
                                                                String info4=w7.textFieldMin.getText();
                                                                String info5=(String) w7.comboBoxPe.getSelectedItem();
                                                                String info6=w7.textFieldSem.getText();
                                                                if(curs.isEmpty() || info1.isEmpty() || info2.isEmpty() || info3.isEmpty() || info4.isEmpty()|| info5.isEmpty()|| info6.isEmpty()){
                                                                    JOptionPane.showMessageDialog(null,"Error: favor de llenar los campos","Llenar campos",JOptionPane.ERROR_MESSAGE);
                                                                    //abortar transacción
                                                                }//end if
                                                                JOptionPane.showConfirmDialog(null,"Se ha registrado exitosamente","Registro",JOptionPane.OK_OPTION,JOptionPane.INFORMATION_MESSAGE);
                                                                String form= curs + info1 + info2 + info3 + info4 + info5 + info6;
                                                                textArea.setText(form);
                                                                w7.dispose();
                                                            }
                                                        });
                                                    }//end if
                                                    if(op.equals("2")){
                                                        Vop2 w8= new Vop2();
                                                        w8.setVisible(true);
                                                        w8.BtnAcept.addActionListener(new ActionListener() {
                                                            public void actionPerformed(ActionEvent e) {
                                                                String curs=w8.textFieldCurs.getText();
                                                                String info1=w8.textFieldHa.getText();
                                                                String info2=w8.textFieldMa.getText();
                                                                String info3=w8.textFieldHn.getText();
                                                                String info4=w8.textFieldMn.getText();
                                                                if(curs.isEmpty() || info1.isEmpty() || info2.isEmpty() || info3.isEmpty() || info4.isEmpty()){
                                                                    JOptionPane.showMessageDialog(null,"Error: favor de llenar los campos","Llenar campos",JOptionPane.ERROR_MESSAGE);
                                                                    //abortar transacción
                                                                }//end if
                                                                int x= JOptionPane.showConfirmDialog(null, "Está seguro de cambiar la programación del curso: " + curs, "Confirmar cambio", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                                                                if(x==0) {
                                                                    String reserv= curs + info1 + info2 + info3 + info4;
                                                                    textArea.setText(reserv);
                                                                    w8.dispose();
                                                                }
                                                                if(x==1 || x==-1){
                                                                    w8.textFieldCurs.setText(null);
                                                                    w8.textFieldHa.setText(null);
                                                                    w8.textFieldMa.setText(null);
                                                                    w8.textFieldHn.setText(null);
                                                                    w8.textFieldMn.setText(null);
                                                                    //colocar que se abortó o no se realizó la transaccion
                                                                }//end if
                                                            }
                                                        });

                                                    }//end if
                                                    if(op.equals("3")){
                                                        Vop2 w9= new Vop2();
                                                        w9.setVisible(true);
                                                        w9.textFieldHa.setVisible(false);
                                                        w9.textFieldMa.setVisible(false);
                                                        w9.textFieldHn.setVisible(false);
                                                        w9.textFieldMn.setVisible(false);
                                                        w9.etPa.setVisible(false);
                                                        w9.etPnv.setVisible(false);
                                                        w9.etHa.setVisible(false);
                                                        w9.etMa.setVisible(false);
                                                        w9.etHn.setVisible(false);
                                                        w9.etMn.setVisible(false);
                                                        w9.etClav.setText("Ingrese la clave del curso a suprimir:");
                                                        w9.BtnAcept.addActionListener(new ActionListener() {
                                                            public void actionPerformed(ActionEvent e) {
                                                                String curs=w9.textFieldCurs.getText();
                                                                if(curs.isEmpty()){
                                                                    JOptionPane.showMessageDialog(null,"Error: favor de llenar los campos","Llenar campos",JOptionPane.ERROR_MESSAGE);
                                                                    //abortar transacción
                                                                }//end if
                                                                int x= JOptionPane.showConfirmDialog(null, "Está seguro de eliminar el curso: "+curs+ " del Horario", "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                                                                if(x==0) {
                                                                    String reserv= w9.textFieldCurs.getText();
                                                                    textArea.setText(reserv);
                                                                    w9.dispose();
                                                                }
                                                                if(x==1 || x==-1){
                                                                    w9.textFieldCurs.setText(null);
                                                                    //colocar que se abortó o no se realizó la transaccion
                                                                }//end if
                                                            }
                                                        });

                                                    }//end if
                                                    w6.dispose();
                                                }
                                            });
                                        }//end if
                                        else{
                                            JOptionPane.showMessageDialog(null,"Error: contraseña incorrecta","Ingresar",JOptionPane.ERROR_MESSAGE);
                                            w5.textField1.setText(null);
                                        }//end else
                                    }
                                });
                            }//end if

                        }
                    });
                }//end if
                if(buttonText=="Salir"){
                    System.exit(0);
                }//end if
               // textArea.setText("You clicked " + buttonText + " \n ");




            }//end if
            else
            {
                textArea.setText("Menu item " + menuName + " is selected " + " \n ");
                if(menuName.equals("Exit"))
                {
                    JOptionPane.showMessageDialog(null, "Good Bye! see you soon");
                    System.exit(0);

                }//end if
            }//end else
        }//end actionPerformed

    


}//end class
