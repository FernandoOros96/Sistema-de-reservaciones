import javax.swing.*;
import java.awt.*;

public class VconsH extends JDialog{
    public JButton Completobtn;
    public JComboBox comboBox1;
    public JComboBox comboBox2;
    public JButton Consbtn;
    private JPanel JPVconsH;
    public VconsH() {
        this.setContentPane(JPVconsH);
        this.pack();

        setLocationRelativeTo(null);
    }//end VconsH

    public static void main (String args[]){
        VconsH w4= new VconsH();
        w4.setVisible(true);

    }//end main
}//end class
