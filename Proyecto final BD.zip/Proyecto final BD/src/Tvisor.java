import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Tvisor extends JFrame{
    public JTable visor;
    public JPanel Jpanel;
    public JScrollPane JTcol;

    public Tvisor() {
        this.setContentPane(Jpanel);
        this.pack();
        setLocationRelativeTo(null);
        setSize(700,500);
        setResizable(true);
    }//end Tvisor

    public static void main (String args[]){
        Tvisor wV= new Tvisor();
        wV.setVisible(true);

    }//end main
}
