import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventanasalon extends JDialog {
    private JPanel main;
    public JComboBox XD;
    public JButton btnOK;
    public String f;

    public Ventanasalon(){

        this.setContentPane(main);
        this.pack();
        setLocationRelativeTo(null);
        btnOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }//end VentanaSalon


    public static void main (String args[]){
        Ventanasalon win= new Ventanasalon();
        win.setVisible(true);

    }//end main
}
