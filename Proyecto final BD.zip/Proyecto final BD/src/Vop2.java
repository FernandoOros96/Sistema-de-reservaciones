import javax.swing.*;

public class Vop2 extends JDialog {
    public JTextField textFieldCurs;
    public JTextField textFieldMa;
    public JTextField textFieldHa;
    public JTextField textFieldHn;
    public JTextField textFieldMn;
    public JButton BtnAcept;
    private JPanel JPop2;
    public JLabel etClav;
    public JLabel etPa;
    public JLabel etPnv;
    public JLabel etHa;
    public JLabel etMa;
    public JLabel etHn;
    public JLabel etMn;

    public Vop2() {
        this.setContentPane(JPop2);
        this.pack();
        setLocationRelativeTo(null);
    }//end VconsH

    public static void main (String args[]){
        Vop2 w8= new Vop2();
        w8.setVisible(true);

    }//end main
}
