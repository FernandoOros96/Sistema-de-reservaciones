import javax.swing.*;

public class Vpswrd extends JDialog{
    public JTextField textField1;
    public JButton ingbtn;
    private JPanel JPpwrd;

    public Vpswrd() {
        this.setContentPane(JPpwrd);
        this.pack();
        setLocationRelativeTo(null);
    }//end VconsH

    public static void main (String args[]){
        Vpswrd w5= new Vpswrd();
        w5.setVisible(true);

    }//end main
}
