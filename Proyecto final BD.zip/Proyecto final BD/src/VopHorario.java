import javax.swing.*;

public class VopHorario extends JDialog {
    public JRadioButton RBmpro;
    public JRadioButton RBsup;
    public JRadioButton RBaent;
    public ButtonGroup group;
    private JPanel JPopHo;
    public JButton aceptarBtn;

    public VopHorario() {
        this.setContentPane(JPopHo);
        this.pack();
        RBaent.setActionCommand("1");
        RBmpro.setActionCommand("2");
        RBsup.setActionCommand("3");
        group=new ButtonGroup();
        group.add(RBaent);
        group.add(RBsup);
        group.add(RBmpro);
        setLocationRelativeTo(null);
    }//end VconsH

    public static void main (String args[]){
        VopHorario w6= new VopHorario();
        w6.setVisible(true);

    }//end main
}
