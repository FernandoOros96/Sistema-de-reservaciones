import javax.swing.*;
import java.awt.*;

public class Jframe {
    public static void main( String[] args ) {

        JFrame defaultJFrame;

        defaultJFrame = new JFrame();

        defaultJFrame.setVisible(true);
    }//end main


}//end class