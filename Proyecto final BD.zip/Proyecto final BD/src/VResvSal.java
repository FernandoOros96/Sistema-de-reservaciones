import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VResvSal extends JDialog {
    public JTextField textField1;
    public JTextField textField2;
    public JButton anularResBtn;
    private JPanel JPVresvS;
    public JButton resvSB;
    public JLabel EtqID;

    public VResvSal() {
        this.setContentPane(JPVresvS);
        this.pack();
        setLocationRelativeTo(null);

    }//end VResvSal

    public static void main (String args[]){
        VResvSal w3= new VResvSal();
        w3.setVisible(true);

    }//end main

}//end class
