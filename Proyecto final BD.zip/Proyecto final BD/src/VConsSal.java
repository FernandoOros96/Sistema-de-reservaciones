import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VConsSal extends JDialog {
    private JPanel JPcons;
    public JTextField textField1;
    public JComboBox comboBox1;
    public JButton OKButton;

    public VConsSal() {
        this.setContentPane(JPcons);
        this.pack();
        setLocationRelativeTo(null);
    }//end VConsSal

    public static void main (String args[]){
        VConsSal w2= new VConsSal();
        w2.setVisible(true);

    }//end main
}
